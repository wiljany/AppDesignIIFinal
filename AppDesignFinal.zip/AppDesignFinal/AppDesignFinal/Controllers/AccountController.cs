﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using AppDesignFinal.Models;
using AppDesignFinal.Helpers;
using AppDomain.Concrete;

namespace AppDesignFinal.Controllers
{
	public class AccountController : Controller
	{

		private ApplicationDbContext db = new ApplicationDbContext();

		//public ActionResult GenerateHash()
		//{
		//	string hash = PasswordHelper.HashPassword("admin1");
		//	return Content(hash);
		//}

		[HttpGet]
		public ActionResult Login()
		{
			return View();
		}



		// Handle login form submission
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Login(LoginViewModel model)
		{
			if (!ModelState.IsValid)
				return View(model);

			string hashedInput = PasswordHelper.HashPassword(model.Password);

			var user = db.UploadFiles.FirstOrDefault(u => u.Email == model.Email && u.Password == hashedInput);
			// TODO: Replace this with your real user validation logic
			if (user != null)
			{
				FormsAuthentication.SetAuthCookie(user.Email, false);
				return RedirectToAction("Index", "Admin");
			}

			ModelState.AddModelError("", "Invalid email or password");
			return View(model);
		}

		//// Log out user
		//[HttpPost]
		//[ValidateAntiForgeryToken]
		public ActionResult Logout()
		{
			FormsAuthentication.SignOut();
			return RedirectToAction("Index", "Home");
		}
	}
}